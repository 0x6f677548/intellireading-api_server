from intellireading.api_server.main import entrypoint

if __name__ == "__main__":
    entrypoint()

from intellireading.client.app import entrypoint

if __name__ == "__main__":
    entrypoint()

from intellireading.client.app import entrypoint

# flake8: noqa : F401
from intellireading.client.metaguiding import metaguide_epub, metaguide_xhtml, metaguide_dir
